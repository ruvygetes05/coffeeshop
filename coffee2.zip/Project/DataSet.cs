﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoffeeShopConsole
{

    class DataSet
    {
        public static List<Orders> OrderList = new List<Orders>();
    }
}
