﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoffeeShopConsole
{
    class Orders
    {
        public int Capuccino, Americano, Creama, Ice;
        public int Cheese, Strawberry, Choco, Banana;
        public int Total, GrandTotal;
        public string myOrder;
        public int cap, ame, cre, ic;
        public int ches, straw, choc, ban;
        public Orders(int capuccino, int americano, int creama, int ice, int cheese,
            int strawberry, int choco, int banana)
        {
            cap = capuccino;
            ame= americano;
            cre= creama;
            ic = ice;
            ches = Cheese;
            straw = strawberry;
            choc = choco;
            ban = banana;
            if (capuccino != 0)
            {
                this.Capuccino = capuccino * 20;
            }
            if (americano != 0)
            {
                this.Americano = americano * 25;
            }
            if (creama != 0)
            {
                this.Creama = creama * 15;
            }
            if (ice != 0)
            {
                this.Ice = ice * 20;
            }
            if (cheese != 0)
            {
                this.Cheese = cheese * 45;
            }
            if (strawberry != 0)
            {
                this.Strawberry = strawberry * 50;
            }
            if (choco != 0)
            {
                this.Choco = choco * 60;
            }
            if (banana != 0)
            {
                this.Banana = banana * 30;
            }
            Total = this.Capuccino + this.Americano + this.Creama + this.Ice +
        this.Cheese + this.Strawberry + this.Choco + this.Banana;
            GrandTotal += Total;
           
        }
        public string output()
        {
            Console.WriteLine("\t Order\t\t\t\tQuantity\t\tAmount");
            
            if (Capuccino != 0)
            {

                myOrder += "\tCapuccino *\t\t\t" + cap + "\t\t\t" + this.Capuccino + "\n";
            }
            if (Americano != 0)
            {
                myOrder += "\tAmericano *\t\t\t" + ame + "\t\t\t" + this.Americano + "\n";
            }
            if (Creama != 0)
            {
                myOrder += "\tCreama *\t\t\t" + cre + "\t\t\t" + this.Creama + "\n";
            }
            if (Ice != 0)
            {

                myOrder += "\tIce Coffee *\t\t\t" + ic + "\t\t\t" + this.Ice + "\n";
            }
            if (Cheese != 0)
            {
                myOrder += "\tCheese Cake *\t\t\t" + ches + "\t\t\t" + this.Cheese + "\n";
            }
            if (Strawberry != 0)
            {
                myOrder += "\tStrawberry Cake *\t\t" + straw + "\t\t\t" + this.Strawberry + "\n";
            }
            if (Choco != 0)
            {
                myOrder += "\tChocolate Cake *\t\t" + choc + "\t\t\t" + this.Choco + "\n";
            }
            if (Banana != 0)
            {
                myOrder += "\tBanana Cake *\t\t\t" + ban + "\t\t\t" + this.Banana + "\n";
            }
            myOrder += "\n\n\t\t\tTotal:            " + GrandTotal;
            Console.Write(myOrder.ToString());
            float cash, change;
            Console.Write("\n\t\t\tInput Cash:       ");
            cash = float.Parse(Console.ReadLine());
            change = cash - Total;
            Console.WriteLine("\t\t\tChange :          " + change);
            return myOrder;

        }
    }
}

