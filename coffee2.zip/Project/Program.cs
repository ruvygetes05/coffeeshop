﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoffeeShopConsole
{
    class Program
    {
        int capuccino = 0, americano = 0, creama = 0, ice = 0;
        int strawberry = 0, choco = 0, banana = 0;
        static void Main(string[] args)
        {
            Program program = new Program();
            program.home();
        }
        public char menu()
        {
            Console.Clear();
            design();
            Console.Write("\n\t     WELCOME TO PRECIOUS VY-ANN COFFEE SHOP  \n\n");
            Console.Write("\n\t     COFFEEs\t\t\t     CAKES\n\n");
            Console.Write("\t[a] P20 Cappuccino\t\t[e] P50 Strawberry Cake\n");
            Console.Write("\t[b] P15 Creama\t\t\t[f] P30 Banana Cake\n");
            Console.Write("\t[c] P25 Americano\t\t[g] P60 Chocolate Cake\n");
            Console.Write("\t[d] P20 Ice Coffee");
            Console.Write("\n\n\t\t\t\t[y] Submit \n");
           
            design();
        bc:
            char ch='c';
            Console.Write("Select your Choice:");
            try
            {
                ch = char.Parse(Console.ReadLine());

            }
            catch
            {
                invalid();
                Console.ReadKey();
                goto bc;
            }
            return ch;
        }
        public void design()
        {
            Console.Write("\n**************************************************************\n");
        }
      
        public void home()
        {
            Orders newOrder;
        bck:
            try
            {
                switch (menu())
                {
                    case 'a':
                    case 'A':
                        capuccino = orderQuantity();
                        newOrder = new Orders(capuccino, americano, creama, ice, strawberry, choco, banana);
                        DataSet.OrderList.Add(newOrder);
                        home();
                        break;
                    case 'b':
                    case 'B':
                        creama = orderQuantity();
                        newOrder = new Orders(capuccino, americano, creama, ice,strawberry, choco, banana);
                        DataSet.OrderList.Add(newOrder);
                        home();
                        break;
                    case 'c':
                    case 'C':
                        americano = orderQuantity();
                        newOrder = new Orders(capuccino, americano, creama, ice, strawberry, choco, banana);
                        DataSet.OrderList.Add(newOrder);
                        home();
                        break;
                    case 'd':
                    case 'D':
                        ice = orderQuantity();
                        newOrder = new Orders(capuccino, americano, creama, ice, strawberry, choco, banana);
                        DataSet.OrderList.Add(newOrder);
                        home();
                        break;
                    case 'e':
                    case 'E':
                        strawberry = orderQuantity();
                        newOrder = new Orders(capuccino, americano, creama, ice, strawberry, choco, banana);
                        DataSet.OrderList.Add(newOrder);
                        home();
                        break;
                    case 'F':
                    case 'f':
                        banana = orderQuantity();
                        newOrder = new Orders(capuccino, americano, creama, ice, strawberry, choco, banana);
                        DataSet.OrderList.Add(newOrder);
                        home();
                        break;
                    case 'g':
                    case 'G':
                        choco = orderQuantity();
                        newOrder = new Orders(capuccino, americano, creama, ice, strawberry, choco, banana);
                        DataSet.OrderList.Add(newOrder);
                        home();
                        break;
                    case 'y':
                    case 'Y':
                        submit();
                        newOrder = new Orders(capuccino = 0, americano = 0, creama = 0, ice = 0, strawberry = 0, choco = 0, banana = 0);
                        home();
                        break;
                    default:
                        invalid();
                        Console.ReadKey();
                        goto bck;
                            break;
                     

                };
            }
            
            catch
            {
                invalid(); Console.ReadKey(); 
           
            }
        }

        public int orderQuantity()
        {
        gb:
            int q;
            Console.Write("Quantity: ");
            try
            {
                q = int.Parse(Console.ReadLine());
            }
            catch
            {
                invalid();
                Console.ReadKey();
                goto gb;
            }
            return q;
        }
        public void invalid()
        {
            Console.Write("\tInvalid Input!!\n\n");
        }
        public void viewOrder()
        {
           
            Orders o = new Orders(capuccino, americano, creama, ice, strawberry, choco, banana);
            o.output();
            Console.ReadKey();
          
        }
       
        public void submit()
        {
            Console.Clear();
            design();
            design();
            Console.Write("\t\t PRECIOUS VY-ANN COFFEE CONSOLE\n\n");
            Orders o = new Orders(capuccino, americano, creama, ice, strawberry, choco, banana);
            o.output();
            design();
            design();
            Console.ReadKey();
        }


    }

}
